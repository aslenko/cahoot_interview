﻿/* indexes */
CREATE NONCLUSTERED INDEX IX_Posts_PostTypeId_Asc
ON dbo.Posts ([PostTypeId] ASC);

CREATE NONCLUSTERED INDEX IX_Posts_CreationDate_Asc
ON dbo.Posts ([CreationDate] ASC);

CREATE NONCLUSTERED INDEX IX_Votes_PostId_Asc_VoteTypeId_Asc
ON dbo.Votes ([PostId] ASC, [VoteTypeId] ASC);

CREATE NONCLUSTERED INDEX IX_Users_CreationDate_Asc
ON dbo.Users ([CreationDate] ASC);

/* functions */
CREATE FUNCTION FirstDateOfTheWeek(@Date DATE)
RETURNS DATE AS 
BEGIN
	RETURN DATEADD(dd, @@DATEFIRST - DATEPART(dw, @Date) - 6, @Date);
END; 

/* views */
CREATE VIEW dbo.vwAnswerQuestionPosts AS 
SELECT p.*, pt.[Type] AS PostType
FROM dbo.[Posts] p
INNER JOIN dbo.[PostTypes] pt ON pt.Id = p.PostTypeId
WHERE p.PostTypeId IN (1, 2) -- 1 - Question, 2 - Answer

CREATE VIEW dbo.vwUpVotes AS 
SELECT PostId, VoteTypeId
FROM dbo.[Votes] 
WHERE VoteTypeId = 2

CREATE VIEW dbo.vwDownVotes AS 
SELECT PostId, VoteTypeId
FROM dbo.[Votes] 
WHERE VoteTypeId = 3

CREATE VIEW dbo.vwUsersCreatedPerWeek AS
SELECT dbo.FirstDateOfTheWeek(CreationDate) AS 'Week',
COUNT(Id) AS Total	
FROM dbo.[Users]
GROUP BY dbo.FirstDateOfTheWeek(CreationDate)

/* functions */
ALTER FUNCTION dbo.SearchPosts(@Search VARCHAR(256))
	RETURNS @posts TABLE (
        Id INT,
        Title NVARCHAR(250),
        Body NVARCHAR(MAX),
        TotalVotes INT,
        TotalAnswers INT,
		OwnerUserId INT,
		OwnerUserDisplayName NVARCHAR(40),
		OwnerUserReputation INT,
		OwnerUserBadges NVARCHAR(MAX),
		TotalCount INT
    )
AS
BEGIN 

	/* TODO: address performance for LIKE queries */
	/* For now just title, TODO: if time permits, add body, tag, user, score searches */
	IF (LEN(@Search) > 0)
	BEGIN

		/* search by title */
		INSERT INTO @posts
		SELECT 
			p.Id, 
			p.Title, 
			p.Body,
			IsNull(votes_count.TotalVotes, 0) AS TotalVotes,
			p.AnswerCount AS TotalAnswers,
			IsNull(p.OwnerUserId, '') AS OwnerUserId,
			IsNull(u.DisplayName, '') AS OwnerUserDisplayName, 
			IsNull(u.Reputation, 0) AS OwnerUserReputation,
			IsNull(ub.Badges, '') AS OwnerUserBadges, 
			0 AS TotalCount
		FROM (
			SELECT * FROM dbo.vwAnswerQuestionPosts
			WHERE Title LIKE '%' + @Search + '%'
		) p
		LEFT JOIN (
			SELECT PostId, COUNT(PostId) AS TotalVotes
			FROM dbo.[Votes]
			GROUP BY PostId
		) votes_count ON votes_count.PostId = p.Id
		LEFT JOIN dbo.[Users] u ON u.Id = p.OwnerUserId 
		LEFT JOIN (
			SELECT UserId, STRING_AGG(CAST([Name] AS NVARCHAR(MAX)), ',') AS Badges
			FROM dbo.[Badges]
			GROUP BY UserId
		) ub ON ub.UserId = u.Id
		ORDER BY p.CreationDate DESC;
		
	END
	ELSE 
	BEGIN

		/* return latest 10 */
		INSERT INTO @posts
		SELECT 
			p.Id, 
			p.Title, 
			p.Body,
			IsNull(votes_count.TotalVotes, 0) AS TotalVotes,
			p.AnswerCount AS TotalAnswers,
			IsNull(p.OwnerUserId, '') AS OwnerUserId,
			IsNull(u.DisplayName, '') AS OwnerUserDisplayName,  
			IsNull(u.Reputation, 0) AS OwnerUserReputation,
			IsNull(ub.Badges, '') AS OwnerUserBadges, 
			0 AS TotalCount
		FROM (
			SELECT TOP 10 * FROM dbo.vwAnswerQuestionPosts
		) p
		LEFT JOIN (
			SELECT PostId, COUNT(PostId) AS TotalVotes
			FROM dbo.[Votes]
			GROUP BY PostId
		) votes_count ON votes_count.PostId = p.Id
		LEFT JOIN dbo.[Users] u ON u.Id = p.OwnerUserId 
		LEFT JOIN (
			SELECT UserId, STRING_AGG(CAST([Name] AS NVARCHAR(MAX)), ',') AS Badges
			FROM dbo.[Badges]
			GROUP BY UserId
		) ub ON ub.UserId = u.Id
		ORDER BY p.CreationDate DESC;
		
	END

	UPDATE @posts SET TotalCount = (SELECT COUNT(*) FROM @posts);

	RETURN;
END;

