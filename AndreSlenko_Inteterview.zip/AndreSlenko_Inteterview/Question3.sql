/* Write an SQL query to calculate and list the aggregate weekly data as follows for all the
weeks in the database in the reverse chronological order (DESC). 
The list should contain 
- the first date of the week, 
- Count of questions (PostTypeId 1 - Question), 
- Count of answers (PostTypeID 2 - Answer), 
- Count of accepted answers (Posts.AcceptedAnswerId), 
- Count of votes (Votes), 
- Total number of new users and active users in that given week
My notes: 
active users - are all the users who existed that week or prior
new users - users who were created that week
*/

SELECT p.*, u_active.Total AS 'TotalActiveUsers', u_new.Total AS 'TotalNewUsers'
FROM (
	SELECT dbo.FirstDateOfTheWeek(p.CreationDate) AS 'Week', 
	SUM(CASE WHEN p.PostTypeId = 1 THEN 1 ELSE 0 END) AS 'TotalQuestions', 
	SUM(CASE WHEN p.PostTypeId = 2 THEN 1 ELSE 0 END) AS 'TotalAnswers', 
	SUM(CASE WHEN p.AcceptedAnswerId > 0 THEN 1 ELSE 0 END) AS 'TotalAcceptedAnswers', 
	SUM(votes_count.TotalVotes) AS 'TotalVotes'	
	FROM dbo.[Posts] p
	LEFT JOIN (
		SELECT PostId, COUNT(PostId) AS TotalVotes
		FROM dbo.[Votes]
		GROUP BY PostId
	) votes_count ON votes_count.PostId = p.Id
	GROUP BY dbo.FirstDateOfTheWeek(p.CreationDate)
) p
LEFT JOIN (
    SELECT * FROM dbo.vwUsersCreatedPerWeek
) u_new ON u_new.Week = p.Week
LEFT JOIN (
	SELECT SUM(Total) OVER(ORDER BY [Week]) AS Total, [Week]
	FROM (
		SELECT * FROM dbo.vwUsersCreatedPerWeek
	) T
) u_active ON u_active.Week = p.Week
ORDER BY p.Week DESC;