import React, { useEffect, useReducer } from "react";
import { defaultConfig, apiConfig, useFetch, useFetchReducer, useFetchesReducer, useFetches } from "../../data/fetch";
import { clone, isNull, isNotNull } from '../../utilities/core';

/**
 * Utility wrapper containing helper objects and functions
 */
const utility = {

    initialState: () => {
        return {
            posts: [],           
            page: {
                /** number of items per page */
                size: 10,
                /** total number of items */
                totalElements: 0,
                /** total number of pages */
                totalPages: 1,
                /** current page index */
                number: 1
            },
            sort: [
                {
                    dataField: 'score',
                    order: 'asc'
                }
            ],
            filter: {
                title: ''               
            }           
        };
    },    

    reducer: (state, action) => {
        switch (action.type) {           
            case 'UPDATE_POSTS':
                return {
                    ...state,
                    posts: action.payload
                };            
            case 'UPDATE_PAGE':
                return {
                    ...state,
                    page: action.payload
                };
            case 'UPDATE_FILTER':
                return {
                    ...state,
                    filter: action.payload
                };
            case 'UPDATE_SORT':
                return {
                    ...state,
                    sort: action.payload
                };
            default:
                return {
                    ...state
                };
        }
    }
}

/**
 * Search Posts Reducer
 * NOTES:
 * 1) We must separate reducer (useLayoutListReducer) from wrapper (useLayoutList) otherwise we might encounter situations where reducer action is fired twice.
 *    Please see this link (https://stackoverflow.com/questions/54892403/usereducer-action-dispatched-twice/54894698) for explanation.
 */
export function useSearchPostsReducer() {
    //returns the reducer itself (not just its state)
    const initialState = utility.initialState();
    return useReducer(utility.reducer, initialState);
}

/**
 * Layout List wrapper for managing reducer state
 * @param state - state of useSearchPostsReducer
 * @param dispatch - dispatch of useSearchPostsReducer
 * @param messageActions - popup message actions
 * @param toastActions - toast message actions
 * @returns {*[]}
 */
export default function useSearchPosts(state, dispatch, messageActions, toastActions) {
    const fetchPostsConfig = { ...clone(defaultConfig), url: apiConfig.serviceUrl + 'posts/SearchPosts?search={SEARCH}' };
    const [statePosts, dispatchPosts] = useFetchReducer();
    const [_fetchPosts] = useFetch(statePosts, dispatchPosts, "Loading Posts", messageActions, toastActions);
   
    function fetchPosts(search) {
        console.info('<<<<<<fetchPosts>>>>', { search });
       
        const fetchPostsConfigClone = clone(fetchPostsConfig);
        fetchPostsConfigClone.url = fetchPostsConfigClone.url
            .replace("{SEARCH}", search);

        _fetchPosts(fetchPostsConfigClone);
    }

    function updatePosts(posts) {
        dispatch({ type: 'UPDATE_POSTS', payload: posts });
    }

    function updatePage(page) {
        dispatch({ type: 'UPDATE_PAGE', payload: page });
    }

    function updateFilter(filter) {
        console.log('Updating filter...', filter);
        dispatch({ type: 'UPDATE_FILTER', payload: filter });
    }

    function updateSort(sort) {
        dispatch({ type: 'UPDATE_SORT', payload: sort });
    }   

    useEffect(() => {
        if (isNotNull(statePosts.response) && isNotNull(statePosts.response.data)) {
            const posts = statePosts.response.data;
            updatePosts(posts);
            //statePosts.response.data.page.number += 1;
            //updatePage(statePosts.response.data.page);            
        }
    }, [statePosts.response]);   

    const actions = {
        fetchPosts,       
        updatePosts,
        updatePage,
        updateFilter,
        updateSort       
    }

    return [actions];
}
