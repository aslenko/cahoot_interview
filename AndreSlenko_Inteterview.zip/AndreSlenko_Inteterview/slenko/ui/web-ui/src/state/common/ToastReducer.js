import { useReducer } from 'react';
import { findIndex } from 'lodash';

/**
 * Hook for managing toast messages
 */
export default function useToastReducer() {

    const reducer = (state, action) => {
        let messages = state.messages;
        const message = action.payload;
        let foundIndex = -1;

        switch (action.type) {
            case 'ADD_TOAST':
                foundIndex = findIndex(messages, (item) => {
                    return item.title === message.title &&
                        item.message === message.message &&
                        item.type === message.type});

                if (foundIndex < 0) {
                    messages.push(message);
                }

                return {
                    ...state,
                    messages: messages
                };
            case 'REMOVE_TOAST':
                foundIndex = findIndex(messages, (item) => {
                    return item.title === message.title &&
                        item.message === message.message &&
                        item.type === message.type});

                if (foundIndex > -1) {
                    messages.splice(foundIndex, 1);
                }

                return {
                    ...state,
                    messages: messages
                };
            default:
                return {
                    ...state
                };
        }
    };

    const [state, dispatch] = useReducer(reducer, { messages: [] });

    function addToast(message) {
        dispatch({ type: 'ADD_TOAST', payload: message });
    }

    function removeToast(message) {
        dispatch({ type: 'REMOVE_TOAST', payload: message });
    }

    return [state, addToast, removeToast];
}