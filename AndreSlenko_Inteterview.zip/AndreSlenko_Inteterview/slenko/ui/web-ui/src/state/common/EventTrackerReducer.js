import { useReducer } from 'react';
import { findIndex } from 'lodash';
import {clone} from "../../utilities/core";

/**
 * Hook for managing events between components and reducers
 */
export default function useEventTrackerReducer(onChange) {

    const reducer = (state, action) => {
        const events = state.events;

        switch (action.type) {
            case 'START_CHANGE':
                events[action.payload.id] = clone({ name: action.payload.name, payload: action.payload.payload });

                return {
                    ...state,
                    events: events
                };
            case 'END_CHANGE':
                delete events[action.payload.id];

                return {
                    ...state,
                    events: events
                };
            default:
                return {
                    ...state
                };
        }
    };

    const [state, dispatch] = useReducer(reducer, { events: {} });

    const change = (name, payload) => {
        const changeId = 'e_' + (new Date().getTime()).toString() + '_' + name;
        dispatch({ type: 'START_CHANGE', payload: { id: changeId, name, payload }});
        onChange(name, payload);
        dispatch({ type: 'END_CHANGE', payload: { id: changeId }});
    }

    return [state, change];
}