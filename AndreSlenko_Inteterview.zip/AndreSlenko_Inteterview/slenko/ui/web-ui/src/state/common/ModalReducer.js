import { useReducer } from 'react';

/**
 * Hook for managing modal dialogs
 */
export default function useModalReducer() {

    const reducer = (state, action) => {
        switch (action.type) {
            case 'SHOW_MODAL':
                return {
                    ...state,
                    ...action.payload
                };
            default:
                return {
                    ...state
                };
        }
    };

    const [state, dispatch] = useReducer(reducer, { show: false, title: null, message: null, buttons: [], onAction: null });

    function showModal(show, title, message, buttons, onAction) {
        dispatch({ type: 'SHOW_MODAL', payload: { show, title, message, buttons, onAction } });
    }

    return [state, showModal];
}