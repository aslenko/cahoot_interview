import { useReducer } from 'react';

/**
 * Hook for managing messages
 */
export default function useMessageReducer() {

    const reducer = (state, action) => {
        let messages = state.messages;
        const message = action.payload;

        switch (action.type) {
            case 'ADD_MSG':
                if (messages.indexOf(message) < 0) {
                    messages.push(message);
                }

                return {
                    ...state,
                    messages: messages
                };
            case 'REMOVE_MSG':
                if (messages.indexOf(message) > -1) {
                    messages.splice(messages.indexOf(message), 1);
                }

                return {
                    ...state,
                    messages: messages
                };
            default:
                return {
                    ...state
                };
        }
    };

    const [state, dispatch] = useReducer(reducer, { messages: [] });

    function addMessage(message) {
        dispatch({ type: 'ADD_MSG', payload: message });
    }

    function removeMessage(message) {
        dispatch({ type: 'REMOVE_MSG', payload: message });
    }

    return [state, addMessage, removeMessage];
}