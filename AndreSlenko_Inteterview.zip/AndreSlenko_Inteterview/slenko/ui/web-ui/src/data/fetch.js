import React, { useState, useEffect, useReducer } from 'react';
import axios from 'axios';
import {isNotNull, isNull, isNullOrEmpty} from '../utilities/core';
import { ToastMessageType } from '../components/common/ToastMessage';

/**
* Default fetch configuration
* NOTE: https://github.com/axios/axios
*/
export const defaultConfig = {
    url : '', /* required */
    method : 'get',
    headers : { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Cache-Control' : 'no-cache' },
    data : null /* only valid for 'PUT', 'POST', 'PATCH' */
};

/**
* API settings (environment specific settings)
*/
export const apiConfig = {
    serviceUrl: 'https://localhost:7018/' //TODO: move to env config
}

/**
 * Utility wrapper containing helper objects and functions
 */
const utilityFetch = {

    initialState: () => {
        return {
            config: null,
            isLoading: false,
            isError: false,
            response: null
        }
    },

    reducer: (state, action) => {
        switch (action.type) {
            case 'UPDATE_CONFIG':
                console.info('++++ setting up configuration ++++ ', action.payload);
                return {
                    ...state,
                    config: action.payload
                };
            case 'FETCH_INIT':
                console.info('>>>> fetching (' + state.config.method + ') data (' + state.config.url + ')...', state.config);
                return {
                    ...state,
                    isLoading: true,
                    isError: false
                };
            case 'FETCH_SUCCESS':
                console.info('<<<< fetching (' + state.config.method + ') data completed (' + state.config.url + ')!', action.payload);
                return {
                    ...state,
                    isLoading: false,
                    isError: false,
                    response: action.payload
                };
            case 'FETCH_FAILURE':
                console.error('<<<< (' + state.config.method + ') data failed (' + state.config.url + ')!', action.payload);
                return {
                    ...state,
                    isLoading: false,
                    isError: true
                };
            default:
                throw new Error("Invalid Action Type (" + action.type + ")");
        }
    }

}

/**
 * Fetch reducer
 */
export function useFetchReducer() {
    //returns the reducer itself (not just its state)
    return useReducer(utilityFetch.reducer, utilityFetch.initialState());
}

/**
 * Hook for fetching data from a single source (configuration) and returning one response
 */
export function useFetch(state, dispatch, message, messageActions, toastActions) {

    const setConfig = (config) => {
        dispatch({ type: 'UPDATE_CONFIG', payload: config });
    }

    useEffect(() => {
        const fetchData = async () => {

            //add message
            if (isNotNull(messageActions))
                messageActions.addMessage(message);

            dispatch({ type: 'FETCH_INIT' });

            try {
                const result = await axios(state.config);
                dispatch({ type: 'FETCH_SUCCESS', payload: result });
            } catch (error) {
                let message = error.toString();

                //check if we have a user-friendly error message
                if (isNotNull(error.response) &&
                    isNotNull(error.response.data)) {

                    if (Array.isArray(error.response.data) &&
                        error.response.data.length > 0 &&
                        !isNullOrEmpty(error.response.data[0].userMsg)) {
                        message = error.response.data[0].userMsg;
                    } else if (isNotNull(error.response.data._embedded) &&
                        Array.isArray(error.response.data._embedded.errorResponses) &&
                        error.response.data._embedded.errorResponses.length > 0) {
                        message = error.response.data._embedded.errorResponses[0].userMsg;
                    }
                }

                if (isNotNull(toastActions)) {
                    toastActions.addToast({title: 'Error', message: message, type: ToastMessageType.ERROR});
                }

                dispatch({ type: 'FETCH_FAILURE', payload: message });
            } finally {
                //remove message
                if (isNotNull(messageActions))
                    messageActions.removeMessage(message);
            }
        };

        if (isNotNull(state.config)) {
            fetchData();
        }

    }, [state.config]);

    return [setConfig];
}

/**
 * Utility wrapper containing helper objects and functions
 */
const utilityFetches = {

    initialState: () => {
        return {
            configs: null,
            completedResponses: [], //temp responses
            isLoading: false,
            isError: false,
            response: [] //responses after all fetches complete
        }
    },

    reducer: (state, action) => {
        let response = null;
        let error = null;
        let index = null;
        let config = null;

        switch (action.type) {
            case 'UPDATE_CONFIGS':
                const { configs } = action.payload;
                console.info('++++ setting up multiple configurations ++++ ', configs.length);
                return {
                    ...state,
                    completedResponses: [],
                    configs: configs
                };
            case 'FETCH_INIT':
                ({ config, index } = action.payload);
                console.info('>>>> fetching (' + config.method + ') data (' + config.url + ')...', config);
                return {
                    ...state,
                    isLoading: true,
                    isError: false
                };
            case 'FETCH_SUCCESS':
                ({ response, config, index } = action.payload);
                const completedResponses = state.completedResponses;
                completedResponses.push(response);
                const done = completedResponses.length === state.configs.length;

                console.info('<<<< fetching (' + config.method + ') data completed (' + config.url + ')!' + (done ? ' DONE!': ''), response);

                //let's see if we got everything back
                if (done) {
                    //we're done, all responses have been received
                    return {
                        ...state,
                        isLoading: false,
                        isError: false,
                        completedResponses: [],
                        response: completedResponses,
                    };
                } else {
                    //there are still more responses left
                    return {
                        ...state,
                        completedResponses: completedResponses,
                    };
                }
            case 'FETCH_FAILURE':
                ({ error, config, index } = action.payload);
                console.error('<<<< (' + config.method + ') data failed (' + config.url + ')!', error);
                return {
                    ...state,
                    isLoading: false,
                    isError: true
                };
            default:
                throw new Error("Invalid Action Type (" + action.type + ")");
        }
    }

}

/**
 * Fetches reducer
 * @param initialConfigs
 * @returns {[React.ReducerState<utilityFetches.reducer>, React.Dispatch<React.ReducerAction<utilityFetches.reducer>>]}
 */
export function useFetchesReducer() {
    //returns the reducer itself (not just its state)
    return useReducer(utilityFetches.reducer, utilityFetches.initialState());
}

/**
 * Hook for fetching data from multiple sources (configurations) and returning one result containing multiple responses
 */
export function useFetches(state, dispatch, message, messageActions, toastActions) {

    const setConfigs = (configs) => {
        dispatch({ type: 'UPDATE_CONFIGS', payload: { configs }});
    }

    useEffect(() => {

        const fetchData = async (config, index) => {

            dispatch({ type: 'FETCH_INIT', payload: {config, index} });

            //add message
            if (isNotNull(messageActions))
                messageActions.addMessage(message);

            try {
                const response = await axios(config);
                dispatch({ type: 'FETCH_SUCCESS', payload: { response, config, index } });
            } catch (error) {
                //remove message
                if (isNotNull(messageActions))
                    messageActions.removeMessage(message);

                if (isNotNull(toastActions))
                    toastActions.addToast({ title: 'Error', message: error.toString(), type: ToastMessageType.ERROR });

                dispatch({ type: 'FETCH_FAILURE', payload: { error, config, index } });
            } finally {
                const last = state.configs.length === state.completedResponses.length;
                if (last) {
                    //remove message
                    if (isNotNull(messageActions))
                        messageActions.removeMessage(message);
                }
            }
        };

        //loop through all configurations and initiate fetching
        if (isNotNull(state.configs)) {
            for (let c = 0; c < state.configs.length; c++) {
                const config = state.configs[c];
                fetchData(config, c);
            }
        }

    }, [state.configs]);

    return [setConfigs];
};
