import logo from './logo.svg';
import './App.css';
import React from 'react';
import './styles/site.scss';
import { BrowserRouter as Router } from 'react-router-dom';
import ApplicationRoutes from './components/common/ApplicationRoutes';
import Header from './components/common/Header';
import Footer from './components/common/Footer';
import HtmlComment from "./components/common/HtmlComment";
import ProgressMessage from './components/common/ProgressMessage';
import ToastMessage from './components/common/ToastMessage';
import ModalMessage from './components/common/ModalMessage'
import useMessageReducer from './state/common/MessageReducer';
import useToastReducer from './state/common/ToastReducer';
import useModalReducer from './state/common/ModalReducer';

export default function App() {
    const [messageState, addMessage, removeMessage] = useMessageReducer();
    const [toastState, addToast, removeToast] = useToastReducer();
    const [modalState, showModal] = useModalReducer();

    return (
        <Router>
          <div className="app">
              <HtmlComment comment="Header" />
              <Header />
              <HtmlComment comment="Main" />
              <main>
                    <ApplicationRoutes messageActions={{ addMessage, removeMessage }} toastActions={{ addToast }} modalActions={{ showModal }} />
              </main>
              <HtmlComment comment="Footer" />
              <Footer />
          </div>
          <ProgressMessage messages={messageState.messages} />
          <ToastMessage messages={toastState.messages} removeToast={removeToast} />
          <ModalMessage show={modalState.show} title={modalState.title} message={modalState.message} buttons={modalState.buttons} onAction={modalState.onAction} showModal={showModal} />
        </Router>
  );
}
