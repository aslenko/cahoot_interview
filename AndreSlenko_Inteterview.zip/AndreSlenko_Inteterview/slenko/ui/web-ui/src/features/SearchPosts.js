import React, { useEffect, useCallback, useState } from 'react';
import '../styles/flex.scss';
import { InputGroup, FormControl, SplitButton, Dropdown } from 'react-bootstrap';
import useSearchPosts, { useSearchPostsReducer } from '../state/posts/SearchPostsReducer';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { isNull } from '../utilities/core';

export default function SearchPosts(props) {

    const [state, dispatch] = useSearchPostsReducer();
    const [actions] = useSearchPosts(state, dispatch, props.messageActions, props.toastActions);

    useEffect(() => {
        //set title
        document.title = `Posts`;

        //initiate fetching of posts
        actions.fetchPosts(state.filter.title);
    }, []);

    useEffect(() => {
        //initiate fetching of posts when certain properties change
        actions.fetchPosts(state.filter.title);
    }, [
        state.page.number,
        state.page.size,
        state.sort[0].dataField,
        state.sort[0].order]);    

    const handleSearch = useCallback((e) => {
        console.info('Search clicked!', e);
        actions.fetchPosts(state.filter.title);
    },
        [state.filter] // Tells React to memoize regardless of arguments.
    );

    const renderPost = (post) => {
        return (
            <div key={post.id} className="flex-item full" style={{ borderBottom: '1px solid #cccccc'}}>
                <div className="flex-container nowrap">
                    <div className="flex-item" style={{minWidth: '150px'}}>
                        <div className="flex-container nowrap">
                            <div className="flex-item">#Votes: {post.totalVotes}</div>
                        </div>
                        <div className="flex-container nowrap">
                            <div className="flex-item">#Answers: {post.totalAnswers}</div>
                        </div>
                    </div>
                    <div className="flex-item">
                        <div className="flex-container wrap">
                            <div className="flex-item full">
                                <span style={{ fontWeight: 'bold', textDecoration: 'underline' }}>{post.title}</span>
                            </div>
                            <div className="flex-item full">
                                {post.body.substring(0, 140)}
                            </div>
                            <div className="flex-item full">
                                <div className="flex-container nowrap">
                                    <div className="flex-item">
                                        <span style={{ fontWeight: 'bold', color: '#4455ff' }}>{post.ownerUserDisplayName}</span>
                                    </div>
                                    <div className="flex-item">
                                        ({post.ownerUserReputation})
                                    </div>
                                </div>
                            </div>
                            <div className="flex-item full">
                                <div className="flex-container wrap">
                                    {
                                        post.ownerUserBadges.split(',').map((b, index) => { return index > 10 ? '.' : (<div className="pill">{b}</div>); })
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
        );
    };

    return (
        <div className="flex-container wrap">
            <div className="flex-item full nopadding">
                <InputGroup className="mb-3">
                    <FormControl
                        aria-label="Enter search text"
                        placeholder="Please specify your search criteria"
                        value={isNull(state.filter.title) ? '' : state.filter.title}
                        onChange={(e) => actions.updateFilter({ title:  e.target.value })} />
                    <SplitButton
                        onClick={handleSearch}
                        variant="outline-secondary"
                        title={ <FontAwesomeIcon icon={faSearch} /> }
                        id="segmented-button-dropdown-2"
                        alignRight
                    >                        
                        <Dropdown.Item href="#">By Title</Dropdown.Item>                       
                    </SplitButton>
                </InputGroup>
            </div>
            <div className="flex-item full nopadding">                
                <div className="flex-container wrap">
                    {
                        state.posts.map((post, index) => {
                            return renderPost(post)
                        })
                    }
                </div>
            </div>
        </div>
    );
}