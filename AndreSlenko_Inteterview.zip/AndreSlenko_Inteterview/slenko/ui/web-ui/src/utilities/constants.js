/**
 * Field Domain types
 */
export const DomainTypes = {
    LOOKUP: 'LOOKUP',
    REGEX: 'REGEX',
    RANGE: 'RANGE'
};
