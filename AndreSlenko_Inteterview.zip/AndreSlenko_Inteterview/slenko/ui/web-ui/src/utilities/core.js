/**
 * Clones (deep) the specified object
 * @param obj - the object to be cloned
 * @param attachTracker - specifies whether to add additional clone properties (__clone_tracker) to track how many times an object has been cloned
 * @returns - cloned object
 */
export function clone(obj, attachTracker = false) {
    if (attachTracker === true) {
        const cloneTrackerProp = '__clone_tracker';
        const cln = JSON.parse(JSON.stringify(obj));
        if (cln.hasOwnProperty(cloneTrackerProp) && typeof cln[cloneTrackerProp] === 'number') {
            cln[cloneTrackerProp] += 1;
        } else {
            cln[cloneTrackerProp] = 0;
        }

        return cln;
    } else {
        return JSON.parse(JSON.stringify(obj));
    }
}

/**
 * Determines whether the specified object is null (or undefined).
 * @param obj - the object to be verified
 * @return - true if null, false otherwise
 */
export function isNull(obj) {
    return obj === null || typeof (obj) === 'undefined';
}

/**
 * Determines whether the specified object is not null (or undefined).
 * @param obj - the object to be verified
 * @return - true if defined, false otherwise
 */
export function isNotNull(obj) {
    return isNull(obj) === false;
}

/**
 * Determines whether the specified string is null or empty.
 * @param str - the string to be verified
 * @return - true if null or empty string, false otherwise
 */
export function isNullOrEmpty(str) {
    return isNull(str) || str.length === 0;
}

/**
 * Removes (deletes) unwanted properties
 * @param obj
 * @param unwantedValues - a list of unwanted values
 */
export function clean(obj, unwantedValues) {
    if (obj == null) {
        return;
    }

    Object.keys(obj).forEach((prop) => {
        const value = obj[prop];

        if (unwantedValues.indexOf(value) > -1) {
            delete obj[prop];
        }  else if (typeof(value) === 'object') {
            clean(value, unwantedValues);
        }
    })
}

/**
 * Checks if the specified array of complex objects has duplicate values for the specified property
 * @param arr - array
 * @param property - property name
 * @returns {boolean} - true if has duplicates, otherwise false
 */
export function hasDuplicates(arr, property) {
    const unique = {};

    arr.forEach((obj) => {
        if (obj.hasOwnProperty(property))
            unique[obj[property]] = true;
        else
            throw new Error("The specified property (" + (isNull(property) ? "NULL" : property) + ") doesn't exist");
    });

    return arr.length !== Object.keys(unique).length;
}

/**
 * Moves an array element from the specified 'from' index to the specified 'to' index shifting other elements as needed
 * @param arr - array
 * @param from - from index
 * @param to - to index
 * @returns {*} - the same modified array
 */
export function move(arr, from, to) {
    arr.splice(to, 0, arr.splice(from, 1)[0]);
    return arr;
}

/**
 * Formats the specified Date represented as string (2019-11-01T12:28:45.708+0000) to MM/DD/YYYY
 * @param dateString - Date represented as string (2019-11-01T12:28:45.708+0000)
 * @returns {string} - formatted Date
 */
export function formatDateFromString(dateString) {
    const dateObj = new Date(dateString);
    return `${('0' + (dateObj.getUTCMonth() + 1)).slice(-2)}/${('0' + dateObj.getUTCDate()).slice(-2)}/${dateObj.getUTCFullYear()}`;
}

/**
 * Converts the specified value into boolean
 * @param value - boolean value in a form of (true|false) or ("true"|"false") or ("1"|"0") or ("y"|"n") or ("t"|"f")
 * @returns {boolean} - boolean value
 */
export function parseBoolean(value) {
    if (isNull(value))
        return false;
    else if (typeof value === 'boolean')
        return value;
    else if (typeof value === 'string' && (value.trim().toLowerCase() === 'y' || value.trim().toLowerCase() === 't'))
        return true;
    else if (typeof value === 'string' && (value.trim().toLowerCase() === 'n' || value.trim().toLowerCase() === 'f'))
        return false;
    else
        return !!JSON.parse(String(value).trim().toLowerCase());
}

/**
 * Copies the specified text to clipboard
 * @param text - the text to be copied
 */
export function copyToClipboard(text) {

    function fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            const successful = document.execCommand('copy');
            console.info(successful ? 'Successfully copied text to clipboard' : 'Could not copy text to clipboard');
        } catch (err) {
            console.error('Error copying to clipboard', err);
        }

        document.body.removeChild(textArea);
    }

    if (!navigator.clipboard) {
        fallbackCopyTextToClipboard(text);
        return;
    }

    navigator.clipboard.writeText(text).then(
        function() {
            console.info('Successfully copied text to clipboard (async)');
        },
        function(err) {
            console.error('Error copying to clipboard (async)', err);
        }
    );
}