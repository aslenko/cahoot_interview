import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, NavDropdown, Form, FormControl, Button } from 'react-bootstrap';

export default function Menu() {
    return (
        <Navbar bg="light" expand="lg">
            <Navbar.Brand href="/">Andre Slenko</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    <NavDropdown title="Posts" id="basic-nav-dropdown">
                        <Link className="dropdown-item" to="/">Search Posts</Link>                                       
                    </NavDropdown>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    );
}

