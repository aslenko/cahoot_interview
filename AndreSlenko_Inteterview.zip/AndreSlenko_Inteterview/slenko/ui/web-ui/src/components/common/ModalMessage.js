import React from 'react';
import { Modal, Button } from 'react-bootstrap';

/**
 * Button variants
 */
export const ModalButtonVariant = {
    PRIMARY: 'primary',
    SECONDARY: 'secondary',
    SUCCESS: 'success',
    WARNING: 'warning',
    DANGER: 'danger',
    INFO: 'info',
    LIGHT: 'light',
    DARK: 'dark',
    LINK: 'link'
}

/**
 * Button types
 */
export const ModalButtonType = {
    OK: 'OK',
    CLOSE: 'Close',
    SAVE: 'Save',
    CANCEL: 'Cancel',
    CUSTOM: 'Custom'
}

/**
 * Commonly used Buttons
 */
export const ModalButtons = {
    OK: { type: ModalButtonType.OK, variant: ModalButtonVariant.PRIMARY, content: ModalButtonType.OK },
    SAVE: { type: ModalButtonType.SAVE, variant: ModalButtonVariant.PRIMARY, content: ModalButtonType.SAVE },
    CANCEL: { type: ModalButtonType.CANCEL, variant: ModalButtonVariant.SECONDARY, content: ModalButtonType.CANCEL },
    CLOSE: { type: ModalButtonType.CLOSE, variant: ModalButtonVariant.SECONDARY, content: ModalButtonType.CLOSE }
}

/**
 * <ModalMessage show={true} title="My Title" message="My Message" buttons={[ModalButtons.CLOSE, ModalButtons.SAVE]} onAction={(e) => console.info(e.type)}/>
 */
export default function ModalMessage({ show, title, message, buttons, onAction, showModal }) {

    if (show) {
        return (
            <Modal
                show={show}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                onHide={() => /* keep this or you get errors */ console.info("hiding...")}
            >
                <Modal.Header>
                    <Modal.Title id="contained-modal-title-vcenter">
                        { title }
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    { message }
                </Modal.Body>
                <Modal.Footer>
                    {
                        buttons.map((b, index) => {
                            return (<Button
                                key={index}
                                variant={b.variant}
                                onClick={(e) => {
                                    //fire event with default args
                                    const args = {button : b, close : true};
                                    onAction(args);

                                    //check if we need to close/hide the dialog
                                    if (args.close === true) {
                                        showModal(false, null, null, [], null);
                                    }
                                }}>
                                {b.content}
                            </Button>)
                        })
                    }

                </Modal.Footer>
            </Modal>
        );
    } else {
        return null;
    }

}