import React from 'react';
import { Toast, Alert } from 'react-bootstrap';
import { isNullOrEmpty, isNotNull } from "../../utilities/core";

/**
 * Toast message type
 */
export const ToastMessageType = {
    INFO: 'info',
    SUCCESS: 'success',
    WARNING: 'warning',
    ERROR: 'error'
}

/**
 * Displays toast messages
 * @param messages - [ { title: 'Message title', message: 'Message to be displayed', type: ToastMessageType.INFO } ]
 * @return - toast messages
 */
export default function ToastMessage({ messages, removeToast }) {

    if (messages.length > 0) {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 0);
        return (
            <div
                aria-live="polite"
                aria-atomic="true"
                style={{
                    position: 'absolute',
                    top: 0,
                    right: 0
                }}
            >
                <div
                    style={{
                        position: 'relative'
                    }}
                >
                    {
                        messages.map((msg, index) => {
                            const show = isNotNull(msg) && !isNullOrEmpty(msg.message);
                            const type = msg.type;
                            let variant = 'info';

                            switch(type) {
                                case ToastMessageType.INFO:
                                    variant = 'info';
                                    break;
                                case ToastMessageType.SUCCESS:
                                    variant = 'success';
                                    break;
                                case  ToastMessageType.WARNING:
                                    variant = 'warning';
                                    break;
                                case ToastMessageType.ERROR:
                                    variant = 'danger';
                                    break;
                            }

                            return (
                                <Toast key={index} onClose={() => removeToast(msg)} show={show} delay={3000} autohide>
                                    <Toast.Body>
                                        <Alert key={index} variant={variant} onClose={() => removeToast(msg)} dismissible>
                                            {msg.message}
                                        </Alert>
                                    </Toast.Body>
                                </Toast>
                            )
                        })
                    }
                </div>
            </div>
        );
    } else {
        return null;
    }
}