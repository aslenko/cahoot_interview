import React, { useEffect, useRef } from 'react';

/*
* Renders HTML comment (<!-- My Comment -->)
* <HtmlComment comment="My Comment"/>
*/
export default function HtmlComment({ comment }) {
    const el = useRef();

    useEffect(() => {
        el.current.outerHTML = `<!-- ${comment} -->`;
    }, []);

    return (
        <div ref={el} />
    );
}