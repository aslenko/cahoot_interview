import React from 'react';
//import LoadingOverlay from 'react-loading-overlay';

/**
* <ProgressMessage messages={["Hello World", "Hello Datanado"]}/>
*/
export default function ProgressMessage({ messages }) {

    if (messages.length > 0) {
        return (
            <div>Loading...</div>
        );
    } else {
        return null;
    }
}