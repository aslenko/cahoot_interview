import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import SearchPosts from '../../features/SearchPosts';

export default function ApplicationRoutes({ messageActions, toastActions, modalActions }) {
    return (        
        <Routes>
            <Route path="/" element={<SearchPosts messageActions={messageActions} toastActions={toastActions} modalActions={modalActions} />} />
            <Route path="/posts" element={<SearchPosts messageActions={messageActions} toastActions={toastActions} modalActions={modalActions} />} />          
        </Routes>       
    );
}


