import React from 'react';

export default function Footer() {
    return (
        <footer>
            {"Copyright � 2022, Andre Slenko and/or its affiliates. All rights reserved."}
            <br />
            {"Having fun coding..."}
        </footer>
    );
}