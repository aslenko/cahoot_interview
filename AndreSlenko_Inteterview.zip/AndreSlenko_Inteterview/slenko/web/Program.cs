using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using web.Data;
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<PostsContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("PostsContext")));

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(
        builder =>
        {
            builder.WithOrigins("https://localhost:7018",
                                "http://localhost")
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowAnyOrigin();
            
        });
});

// Add services to the container.

//builder.Services.AddControllers(); //ASP.NET API controllers
builder.Services.AddControllersWithViews(); //ASP.NET Core API and Razor views
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.UseStaticFiles();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.UseCors();

app.Run();
