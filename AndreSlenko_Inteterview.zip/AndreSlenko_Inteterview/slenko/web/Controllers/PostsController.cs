﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using web.Data;
using web.Models;
using System.Data.Common;

namespace web.Controllers
{
    public class PostsController : Controller
    {
        private readonly PostsContext _context;

        public PostsController(PostsContext context)
        {
            _context = context;
        }


        /// <summary> 
        /// https://localhost:7018/posts/PaginatedList?pageNumber=1&pageSize=10&sortProperty=score&sortOrder=asc
        /// </summary>
        /// <param name="pageNumber">page number (1, 2, 3, ...)</param>
        /// <param name="pageSize">page size</param>
        /// <param name="sortProperty">sort property</param>
        /// <param name="sortOrder">sort order (asc, desc)</param>
        /// <returns>Posts</returns>
        public async Task<PaginatedList<Posts>> PaginatedList(int pageNumber = 1, int pageSize = 10, string sortProperty = "score", string sortOrder = "asc")
        {
            return await PaginatedList<Posts>.CreateAsync(_context.Posts.AsNoTracking().sort(sortProperty, sortOrder), pageNumber < 1 ? 1 : pageNumber, pageSize < 1 ? 20 : pageSize);        
        }

        /// <summary>
        /// https://localhost:7018/posts/SearchPosts?search=Postgres
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public PaginatedList<PostsSearchResponse> SearchPosts(string search = "")
        {
            PostSearchRequest searchRequest = new PostSearchRequest() { Search = search };

            var posts = _context
                .SearchPosts
                .FromSqlInterpolated($"SELECT * FROM dbo.SearchPosts({searchRequest.Search})")
                .Skip((searchRequest.PageNumber - 1) * searchRequest.PageSize)
                .Take(searchRequest.PageSize)
                .ToList();

            int totalCount = posts.Count > 0 ? posts[0].TotalCount : 0;

            return new PaginatedList<PostsSearchResponse>(posts, totalCount, searchRequest.PageNumber, searchRequest.PageSize);               
        }

        // GET: Posts
        public async Task<IActionResult> Index()
        {
            return View(await _context.Posts.Skip(0).Take(20).ToListAsync());
        }

        // GET: Posts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var post = await _context.Posts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        // GET: Posts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Posts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,AcceptedAnswerId,AnswerCount,Body,ClosedDate,CommentCount,CommunityOwnedDate,CreationDate,FavoriteCount,LastActivityDate,LastEditDate,LastEditorDisplayName,LastEditorUserId,OwnerUserId,ParentId,PostTypeId,Score,Tags,Title,ViewCount")] Posts post)
        {
            if (ModelState.IsValid)
            {
                _context.Add(post);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(post);
        }

        // GET: Posts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var post = await _context.Posts.FindAsync(id);
            if (post == null)
            {
                return NotFound();
            }
            return View(post);
        }

        // POST: Posts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,AcceptedAnswerId,AnswerCount,Body,ClosedDate,CommentCount,CommunityOwnedDate,CreationDate,FavoriteCount,LastActivityDate,LastEditDate,LastEditorDisplayName,LastEditorUserId,OwnerUserId,ParentId,PostTypeId,Score,Tags,Title,ViewCount")] Posts post)
        {
            if (id != post.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(post);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PostExists(post.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(post);
        }

        // GET: Posts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var post = await _context.Posts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        // POST: Posts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var post = await _context.Posts.FindAsync(id);
            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PostExists(int id)
        {
            return _context.Posts.Any(e => e.Id == id);
        }
    }
}
