﻿CREATE NONCLUSTERED INDEX IX_Posts_Score_Asc
ON Posts (Score ASC);

