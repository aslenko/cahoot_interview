﻿using System.ComponentModel.DataAnnotations;

namespace web.Models
{
    public class PostsSearchResponse
    {
        public int Id { get; set; }       
        public string? Title { get; set; }
        public string Body { get; set; }
        public int TotalVotes { get; set; }
        public int TotalAnswers { get; set; }
        public int? OwnerUserId { get; set; }
        public string? OwnerUserDisplayName { get; set; }
        public int? OwnerUserReputation { get; set; }
        public string? OwnerUserBadges { get; set; }

        /// <summary>
        /// This is a hack...
        /// </summary>        
        public int TotalCount { get; set; }
    }
}
