﻿using System.ComponentModel.DataAnnotations;

namespace web.Models
{
    public class Posts
    {
        public int Id { get; set; }
        public int? AcceptedAnswerId { get; set; }
        public int? AnswerCount { get; set; }
        public string Body { get; set; }
        [DataType(DataType.Date)]
        public DateTime? ClosedDate { get; set; }
        public int? CommentCount { get; set; }
        [DataType(DataType.Date)]
        public DateTime? CommunityOwnedDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime CreationDate { get; set; }
        public int? FavoriteCount { get; set; }
        [DataType(DataType.Date)]
        public DateTime LastActivityDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime? LastEditDate { get; set; }
        public string? LastEditorDisplayName { get; set; }
        public int? LastEditorUserId { get; set; }
        public int? OwnerUserId { get; set; }
        public int? ParentId { get; set; }
        public int PostTypeId { get; set; }
        public int Score { get; set; }
        public string? Tags { get; set; }
        public string? Title { get; set; }
        public int ViewCount { get; set; }
    }

    public static class PostsExtensions
    {
        public static IQueryable<Posts> sort(this IQueryable<Posts> posts, string property = "score", string order = "asc")
        {            
            switch(property)
            {
                case "score":
                    if (order == "asc")
                        return posts.OrderBy(x => x.Score);
                    else 
                        return posts.OrderByDescending(x => x.Score);
                case "creationDate":
                    if (order == "asc")
                        return posts.OrderBy(x => x.CreationDate);
                    else
                        return posts.OrderByDescending(x => x.CreationDate);
                case "title":
                    if (order == "asc")
                        return posts.OrderBy(x => x.Title);
                    else
                        return posts.OrderByDescending(x => x.Title);
                default:
                    return posts;
            }
        }
    }
}
