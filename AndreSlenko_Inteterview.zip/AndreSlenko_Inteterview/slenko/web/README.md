﻿
To browse the HTTP controllers: https://localhost:7018/WeatherForecast