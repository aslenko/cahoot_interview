This project was created by Andre Slenko 

1) Before running anything, run SQL scripts first ../Queries.sql. This will created indexes, functions, etc...

2) To run ASP.NET Core MVC:
- Open VS 2022 and run the **web** project

3) To run UI (React): 
- install [NodeJS](#https://nodejs.org/en/download/)
- `cd {solution-root}/ui/web-ui`
- run `npm install`
- run `npm install -g serve`
- run `npm run build`
- run `serve -s build` NOTE: You should see a message similar to this: 

  *INFO: Accepting connections at http://localhost:3000*

