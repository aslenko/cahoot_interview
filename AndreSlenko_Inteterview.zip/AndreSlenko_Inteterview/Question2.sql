/* Write an SQL query to find the count of questions and answers in the entire database by
the Day of the week (e.g. Monday, Tuesday) 
ordered by the upvote to downvote ratio in descending order. 
The result should contain 
1) the Post type (Question or Answer),
2) Day of the week (Sunday, Monday etc.), 
3) Total Posts, 
4) Total Upvotes, 
5) Total Downvotes,
6) and Upvotes to Downvotes ratio. */

SELECT t.*, t.TotalUp / t.TotalDown AS 'Ratio' FROM (
    SELECT p.[PostType], 
	DATENAME(WEEKDAY, p.CreationDate) AS 'DayOfWeek',
	COUNT(p.Id) AS 'TotalPostCount',
	SUM(IsNull(up_posts.TotalUp, 0)) AS 'TotalUp', 
	SUM(IsNull(down_posts.TotalDown, 0)) AS 'TotalDown' 
	FROM dbo.[vwAnswerQuestionPosts] p
	LEFT JOIN 
	(	
		SELECT PostId, COUNT(PostId) As TotalUp
		FROM dbo.[vwUpVotes]
		GROUP BY PostId
	) up_posts ON up_posts.PostId = p.Id
	LEFT JOIN
	(
		SELECT PostId, COUNT(PostId) As TotalDown
		FROM dbo.[vwDownVotes]
		GROUP BY PostId
	) down_posts ON down_posts.PostId = p.Id
	GROUP BY p.[PostType], DATENAME(WEEKDAY, p.CreationDate)
) t
ORDER BY t.TotalUp / t.TotalDown DESC;



