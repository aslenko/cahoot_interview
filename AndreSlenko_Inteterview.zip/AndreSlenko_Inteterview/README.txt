The answers to question 2 is in Question2.sql
The answers to question 3 is in Question3.sql
The answers to question 1 is under slenko
	It contains web (ASP.NET Core MVC) and ui (React)
	The instructions on how to run those 2 projects can be found in slenko/README.md
	The web and ui functionality is very basic, it allows for searching posts only by title.
	There are lots of improvements needed: performance of the search function, searches by various properties (tags, users, body), security, proper exception handling, and others
	

